<template>
  <div id="like">
    <div @click="collect">
      <img :src="likeVal" alt="" width="40px" />
    </div>
  </div>
</template>

<script>
export default {
  name: "like",
  data() {
    return {
      //   like: true
    };
  },
  props: {  //获取父组件传递的参数
    like: {   //父组件传递的用户是否已收藏的参数
      type: Boolean,
      default: false,
    },
    id: String   //父组件传递的专辑id
  },
  components: {},

  methods: {
    collect() {   //点击收藏
      if (this.$session.getSession("loginInfo")) {  //判断用户是否已登录
        if (!this.like) {  //判断用户是否已收藏
          let mes = this.$session.getSession("loginInfo");
          this.axios
            .post("/add_collect", {
              user_id: mes.user_id,
              album_id: this.id,
            })
            .then((res) => {
              this.$message({
                type: 'success',
                message: 'Successful collection'
              })
              this.like = true;
            });
        }
      } else {
        this.$message("Please log in first !");
      }
    },
  },
  computed: {
    likeVal() {  //用户已收藏，显示收藏图标，用户未收藏，显示未收藏图标
      if (this.like) {
        return require("../assets/img/收藏.png");
      } else {
        return require("../assets/img/未收藏.png");
      }
    },
  },
};
</script>

<style scoped>
#like {
  width: 50px;
  height: 50px;
}
</style>
